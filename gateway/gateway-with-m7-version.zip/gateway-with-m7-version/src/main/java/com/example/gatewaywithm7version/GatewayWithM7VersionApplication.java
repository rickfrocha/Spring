package com.example.gatewaywithm7version;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayWithM7VersionApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayWithM7VersionApplication.class, args);
	}
}
